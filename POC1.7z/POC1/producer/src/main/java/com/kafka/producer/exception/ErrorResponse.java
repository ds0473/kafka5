package com.kafka.producer.exception;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ErrorResponse {
	
	public ErrorResponse(int status, String message) {
		this.status = status;
		this.message = message;
	}
	private int status;

	

	public List<ValidationError> getErrors() {
		return errors;
	}

	public void setErrors(List<ValidationError> errors) {
		this.errors = errors;
	}

	public int getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	private String message;
	private List<ValidationError> errors;

	private class ValidationError {
		public ValidationError(String field, String message) {
			this.field = field;
			this.message = message;
		}

		private String field;

		public String getField() {
			return field;
		}

		public void setField(String field) {
			this.field = field;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		private String message;
	}

	public void addValidationError(String field, String message) {
		if (Objects.isNull(errors)) {
			errors = new ArrayList<>();
		}
		errors.add(new ValidationError(field, message));
	}
}
